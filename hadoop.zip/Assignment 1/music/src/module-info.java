/**
 * 
 */
/**
 * 
 */
module music {
	requires hadoop.common;
	requires hadoop.mapreduce.client.core;
}